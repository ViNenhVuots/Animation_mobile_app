package com.example.myapplication.feature_physics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

public class SpringGravityView extends View {
    private Paint paint;
    private float ballX = 200f;
    private float ballY = 200f;
    private float radius = 50f;
    private float velocityX = 0f;
    private float velocityY = 0f;
    private boolean isDragging = false;

    public SpringGravityView(Context context) {
        super(context);
        init();
    }

    public SpringGravityView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(0xFF3F51B5);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Draw bouncing ball with simple physics
        canvas.drawCircle(ballX, ballY, radius, paint);

        if (!isDragging) {
            // Apply gravity and bounce
            velocityY += 1.5f; // gravity
            ballX += velocityX;
            ballY += velocityY;

            // Collision with bottom
            if (ballY > getHeight() - radius) {
                ballY = getHeight() - radius;
                velocityY = -velocityY * 0.7f; // damping bounce
                velocityX *= 0.95f; // friction
            }
            // Collision with walls
            if (ballX < radius) {
                ballX = radius;
                velocityX = -velocityX * 0.7f;
            } else if (ballX > getWidth() - radius) {
                ballX = getWidth() - radius;
                velocityX = -velocityX * 0.7f;
            }

            postInvalidateOnAnimation();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                isDragging = true;
                ballX = event.getX();
                ballY = event.getY();
                velocityX = 0;
                velocityY = 0;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getX() - ballX;
                float dy = event.getY() - ballY;
                ballX = event.getX();
                ballY = event.getY();
                velocityX = dx * 0.5f;
                velocityY = dy * 0.5f;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isDragging = false;
                postInvalidateOnAnimation();
                return true;
        }
        return super.onTouchEvent(event);
    }
}
