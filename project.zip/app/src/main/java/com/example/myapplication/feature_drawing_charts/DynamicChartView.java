package com.example.myapplication.feature_drawing_charts;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class DynamicChartView extends View {
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] values = {20f, 50f, 30f, 80f, 60f, 90f, 40f, 75f};

    public DynamicChartView(Context context) {
        super(context);
        init();
    }

    public DynamicChartView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        linePaint.setColor(0xFF4CAF50);
        linePaint.setStrokeWidth(6f);
        linePaint.setStyle(Paint.Style.STROKE);

        textPaint.setColor(0xFF333333);
        textPaint.setTextSize(32f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawText("Dynamic Canvas Chart", 30f, 40f, textPaint);

        float width = getWidth();
        float height = getHeight();
        if (width == 0 || height == 0) return;

        float stepX = width / (values.length + 1);
        for (int i = 0; i < values.length - 1; i++) {
            float startX = (i + 1) * stepX;
            float startY = height - (values[i] / 100f * (height - 60f)) - 10f;
            float endX = (i + 2) * stepX;
            float endY = height - (values[i + 1] / 100f * (height - 60f)) - 10f;
            canvas.drawLine(startX, startY, endX, endY, linePaint);
            canvas.drawCircle(startX, startY, 8f, linePaint);
        }
    }
}
